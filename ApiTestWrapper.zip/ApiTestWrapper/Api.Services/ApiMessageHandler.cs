﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Api.Services
{
    public class ApiMessageHandler: DelegatingHandler
    {
        private const string m_AuthorizationHeader = "Authorization-Token";
        private HttpClientHandler httpClientHandler;
        private string m_Authorization;

        public ApiMessageHandler(HttpMessageHandler innerHandler, string authorization):base(innerHandler)
        {
            m_Authorization = authorization;
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, 
                                                               System.Threading.CancellationToken cancellationToken)
        {
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            String authorization = String.Format("{0}:{1}",
                                                      m_AuthorizationHeader,
                                                      m_Authorization);
            request.Headers.Authorization = new AuthenticationHeaderValue(m_AuthorizationHeader, authorization);
            return base.SendAsync(request, cancellationToken);
        }
    }
}
