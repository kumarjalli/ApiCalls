﻿using Api.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Api.TestWrapper
{
    public partial class ApiTestWrapper : Form
    {
        public ApiTestWrapper()
        {
            InitializeComponent();
        }

        private async void ApiTestWrapper_Load(object sender, EventArgs e)
        {
            string url = "";
            string data = "";
            BaseApiService apiService = new BaseApiService(url, "");
            string result = await apiService.PostAsync(url, "", data);
        }
    }
}
